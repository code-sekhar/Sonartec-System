import { Component } from '@angular/core';

@Component({
  selector: 'app-recruiter-account-settings',
  imports: [],
  templateUrl: './recruiter-account-settings.component.html',
  styleUrl: './recruiter-account-settings.component.css'
})
export class RecruiterAccountSettingsComponent {

}
