import { Component } from '@angular/core';

@Component({
  selector: 'app-recruiter-earnings-overview',
  imports: [],
  templateUrl: './recruiter-earnings-overview.component.html',
  styleUrl: './recruiter-earnings-overview.component.css'
})
export class RecruiterEarningsOverviewComponent {

}
