import { Component } from '@angular/core';

@Component({
  selector: 'app-recruiter-professional-information',
  imports: [],
  templateUrl: './recruiter-professional-information.component.html',
  styleUrl: './recruiter-professional-information.component.css'
})
export class RecruiterProfessionalInformationComponent {

}
