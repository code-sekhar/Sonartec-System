import { Component } from '@angular/core';

@Component({
  selector: 'app-recruiter-personal-information',
  imports: [],
  templateUrl: './recruiter-personal-information.component.html',
  styleUrl: './recruiter-personal-information.component.css'
})
export class RecruiterPersonalInformationComponent {

}
