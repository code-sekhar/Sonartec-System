import { Component } from '@angular/core';

@Component({
  selector: 'app-recruiterformsubmission',
  imports: [],
  templateUrl: './recruiterformsubmission.component.html',
  styleUrl: './recruiterformsubmission.component.css'
})
export class RecruiterformsubmissionComponent {

}
