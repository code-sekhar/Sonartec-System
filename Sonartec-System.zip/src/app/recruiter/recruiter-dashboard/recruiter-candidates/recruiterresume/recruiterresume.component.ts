import { Component } from '@angular/core';

@Component({
  selector: 'app-recruiterresume',
  imports: [],
  templateUrl: './recruiterresume.component.html',
  styleUrl: './recruiterresume.component.css'
})
export class RecruiterresumeComponent {

}
