import { Component } from '@angular/core';

@Component({
  selector: 'app-recruiterjob-applicatin',
  imports: [],
  templateUrl: './recruiterjob-applicatin.component.html',
  styleUrl: './recruiterjob-applicatin.component.css'
})
export class RecruiterjobApplicatinComponent {

}
