import { Component } from '@angular/core';

@Component({
  selector: 'app-recruiterinterview',
  imports: [],
  templateUrl: './recruiterinterview.component.html',
  styleUrl: './recruiterinterview.component.css'
})
export class RecruiterinterviewComponent {

}
