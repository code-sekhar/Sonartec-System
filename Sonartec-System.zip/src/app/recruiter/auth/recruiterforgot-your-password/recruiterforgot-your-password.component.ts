import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-recruiterforgot-your-password',
  imports: [RouterLink],
  templateUrl: './recruiterforgot-your-password.component.html',
  styleUrl: './recruiterforgot-your-password.component.css'
})
export class RecruiterforgotYourPasswordComponent {

}
