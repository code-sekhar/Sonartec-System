import { Component } from '@angular/core';

@Component({
  selector: 'app-forgot-new-password',
  imports: [],
  templateUrl: './forgot-new-password.component.html',
  styleUrl: './forgot-new-password.component.css'
})
export class ForgotNewPasswordComponent {

}
