import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-recruiter-sign-in',
  imports: [RouterLink],
  templateUrl: './recruiter-sign-in.component.html',
  styleUrl: './recruiter-sign-in.component.css'
})
export class RecruiterSignInComponent {

}
