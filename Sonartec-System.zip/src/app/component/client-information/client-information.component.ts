import { Component } from '@angular/core';

@Component({
  selector: 'client-information',
  imports: [],
  templateUrl: './client-information.component.html',
  styleUrl: './client-information.component.css'
})
export class ClientInformationComponent {

}
