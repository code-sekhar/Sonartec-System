import { Component } from '@angular/core';

@Component({
  selector: 'submissin-candidates',
  imports: [],
  templateUrl: './submissin-candidates.component.html',
  styleUrl: './submissin-candidates.component.css'
})
export class SubmissinCandidatesComponent {

}
