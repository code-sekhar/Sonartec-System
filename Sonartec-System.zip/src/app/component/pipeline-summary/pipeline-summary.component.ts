import { Component } from '@angular/core';

@Component({
  selector: 'pipeline-summary',
  imports: [],
  templateUrl: './pipeline-summary.component.html',
  styleUrl: './pipeline-summary.component.css'
})
export class PipelineSummaryComponent {

}
