import { Component } from '@angular/core';

@Component({
  selector: 'draft-job',
  imports: [],
  templateUrl: './draft-job.component.html',
  styleUrl: './draft-job.component.css'
})
export class DraftJobComponent {

}
