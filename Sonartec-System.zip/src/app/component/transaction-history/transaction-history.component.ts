import { Component } from '@angular/core';

@Component({
  selector: 'transaction-history',
  imports: [],
  templateUrl: './transaction-history.component.html',
  styleUrl: './transaction-history.component.css'
})
export class TransactionHistoryComponent {

}
