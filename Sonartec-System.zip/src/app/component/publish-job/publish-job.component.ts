import { Component } from '@angular/core';

@Component({
  selector: 'publish-job',
  imports: [],
  templateUrl: './publish-job.component.html',
  styleUrl: './publish-job.component.css'
})
export class PublishJobComponent {

}
