import { Component } from '@angular/core';

@Component({
  selector: 'amindashboard-score',
  imports: [],
  templateUrl: './amindashboard-score.component.html',
  styleUrl: './amindashboard-score.component.css'
})
export class AmindashboardScoreComponent {

}
