import { Component } from '@angular/core';

@Component({
  selector: 'recruiterdashboardscore',
  imports: [],
  templateUrl: './recruiterdashboardscore.component.html',
  styleUrl: './recruiterdashboardscore.component.css'
})
export class RecruiterdashboardscoreComponent {

}
