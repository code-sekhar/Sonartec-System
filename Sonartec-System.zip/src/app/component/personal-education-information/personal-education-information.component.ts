import { Component } from '@angular/core';

@Component({
  selector: 'personal-education-information',
  imports: [],
  templateUrl: './personal-education-information.component.html',
  styleUrl: './personal-education-information.component.css'
})
export class PersonalEducationInformationComponent {

}
