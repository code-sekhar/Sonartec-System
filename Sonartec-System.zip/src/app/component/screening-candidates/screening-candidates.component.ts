import { Component } from '@angular/core';

@Component({
  selector: 'screening-candidates',
  imports: [],
  templateUrl: './screening-candidates.component.html',
  styleUrl: './screening-candidates.component.css'
})
export class ScreeningCandidatesComponent {

}
