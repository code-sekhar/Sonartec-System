import { Component } from '@angular/core';

@Component({
  selector: 'reports-score',
  imports: [],
  templateUrl: './reports-score.component.html',
  styleUrl: './reports-score.component.css'
})
export class ReportsScoreComponent {

}
