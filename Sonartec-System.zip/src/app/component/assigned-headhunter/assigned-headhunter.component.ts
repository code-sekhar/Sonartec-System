import { Component } from '@angular/core';

@Component({
  selector: 'assigned-headhunter',
  imports: [],
  templateUrl: './assigned-headhunter.component.html',
  styleUrl: './assigned-headhunter.component.css'
})
export class AssignedHeadhunterComponent {

}
