import { Component } from '@angular/core';

@Component({
  selector: 'requestsfrom-headhunters',
  imports: [],
  templateUrl: './requestsfrom-headhunters.component.html',
  styleUrl: './requestsfrom-headhunters.component.css'
})
export class RequestsfromHeadhuntersComponent {

}
