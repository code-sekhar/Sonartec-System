import { Component } from '@angular/core';

@Component({
  selector: 'pending-action',
  imports: [],
  templateUrl: './pending-action.component.html',
  styleUrl: './pending-action.component.css'
})
export class PendingActionComponent {

}
