import { Component } from '@angular/core';

@Component({
  selector: 'job-overview',
  imports: [],
  templateUrl: './job-overview.component.html',
  styleUrl: './job-overview.component.css'
})
export class JobOverviewComponent {

}
