import { Component } from '@angular/core';

@Component({
  selector: 'dashboard-score',
  imports: [],
  templateUrl: './dashboard-score.component.html',
  styleUrl: './dashboard-score.component.css'
})
export class DashboardScoreComponent {

}
