import { Component } from '@angular/core';

@Component({
  selector: 'recruiter-information',
  imports: [],
  templateUrl: './recruiter-information.component.html',
  styleUrl: './recruiter-information.component.css'
})
export class RecruiterInformationComponent {

}
