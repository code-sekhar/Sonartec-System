import { Component } from '@angular/core';

@Component({
  selector: 'app-adminforgot-new-password',
  imports: [],
  templateUrl: './adminforgot-new-password.component.html',
  styleUrl: './adminforgot-new-password.component.css'
})
export class AdminforgotNewPasswordComponent {

}
