import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-adminforgot-your-password',
  imports: [RouterLink],
  templateUrl: './adminforgot-your-password.component.html',
  styleUrl: './adminforgot-your-password.component.css'
})
export class AdminforgotYourPasswordComponent {

}
