import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-admin-create-account',
  imports: [RouterLink],
  templateUrl: './admin-create-account.component.html',
  styleUrl: './admin-create-account.component.css'
})
export class AdminCreateAccountComponent {

}
