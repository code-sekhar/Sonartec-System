import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-payment-traking',
  imports: [],
  templateUrl: './admin-payment-traking.component.html',
  styleUrl: './admin-payment-traking.component.css'
})
export class AdminPaymentTrakingComponent {

}
