import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-subscription-plans',
  imports: [],
  templateUrl: './admin-subscription-plans.component.html',
  styleUrl: './admin-subscription-plans.component.css'
})
export class AdminSubscriptionPlansComponent {

}
