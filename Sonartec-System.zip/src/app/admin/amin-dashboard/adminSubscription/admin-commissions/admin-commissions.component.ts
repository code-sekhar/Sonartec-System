import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-commissions',
  imports: [],
  templateUrl: './admin-commissions.component.html',
  styleUrl: './admin-commissions.component.css'
})
export class AdminCommissionsComponent {

}
