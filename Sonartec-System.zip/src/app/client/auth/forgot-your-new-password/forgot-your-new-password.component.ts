import { Component } from '@angular/core';

@Component({
  selector: 'app-forgot-your-new-password',
  imports: [],
  templateUrl: './forgot-your-new-password.component.html',
  styleUrl: './forgot-your-new-password.component.css'
})
export class ForgotYourNewPasswordComponent {

}
