import { Component } from '@angular/core';

@Component({
  selector: 'app-forgot-your-password',
  imports: [],
  templateUrl: './forgot-your-password.component.html',
  styleUrl: './forgot-your-password.component.css'
})
export class ForgotYourPasswordComponent {

}
