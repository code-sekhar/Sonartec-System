import { Component } from '@angular/core';

@Component({
  selector: 'job-application',
  imports: [],
  templateUrl: './job-application.component.html',
  styleUrl: './job-application.component.css'
})
export class JobApplicationComponent {

}
