import { Component } from '@angular/core';

@Component({
  selector: 'app-form-submission',
  imports: [],
  templateUrl: './form-submission.component.html',
  styleUrl: './form-submission.component.css'
})
export class FormSubmissionComponent {

}
