import { Component } from '@angular/core';

@Component({
  selector: 'app-interview',
  imports: [],
  templateUrl: './interview.component.html',
  styleUrl: './interview.component.css'
})
export class InterviewComponent {

}
