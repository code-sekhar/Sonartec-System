import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-hiring-pipeline',
  imports: [RouterLink],
  templateUrl: './hiring-pipeline.component.html',
  styleUrl: './hiring-pipeline.component.css'
})
export class HiringPipelineComponent {

}
